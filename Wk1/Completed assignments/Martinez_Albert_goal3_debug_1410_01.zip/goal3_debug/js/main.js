/*
Name: Albert Martinez
Date: 10/3/2014
Assignment: Goal3_debug
*/

